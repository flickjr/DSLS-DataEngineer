--Suplier Analysis
SELECT Suppliers.CompanyName, Products.ProductName, SUM("Order Details".Quantity) AS 'Most Sales Product By Quantity', SUM("Order Details".UnitPrice * "Order Details".Quantity) 
AS TotalSales, Products.UnitsInStock as 'Units in stock' , Products.UnitsOnOrder as 'Units in Order'
FROM Suppliers
INNER JOIN Products ON Suppliers.SupplierID = Products.SupplierID
INNER JOIN "Order Details" ON Products.ProductID = "Order Details".ProductID
INNER JOIN Orders ON "Order Details".OrderID = Orders.OrderID
GROUP BY Suppliers.CompanyName, Products.ProductName, Products.UnitsInStock , Products.UnitsOnOrder
ORDER BY TotalSales DESC

--Shipper Analysis
SELECT 
  Customers.City, Region, COUNT(Orders.OrderID) as OrderCount, Shippers.CompanyName as Shipper, Orders.ShipCountry, Orders.ShipCity, Orders.Freight
FROM 
  Orders 
  INNER JOIN Customers ON Orders.CustomerID = Customers.CustomerID
  INNER JOIN Shippers ON Orders.ShipVia = Shippers.ShipperID
GROUP BY 
  Customers.City, Customers.Region, Shippers.CompanyName, Orders.ShipCountry, Orders.ShipCity,Orders.Freight
ORDER BY 
  Freight DESC;


--Employee Analysis
SELECT 
    e.EmployeeID, 
    e.FirstName + ' ' + e.LastName AS EmployeeName,
    e.Title,
    c.CompanyName,
    COUNT(o.OrderID) AS TotalOrders
FROM 
    Employees e
JOIN Orders o ON e.EmployeeID = o.EmployeeID
JOIN Customers c ON o.CustomerID = c.CustomerID
GROUP BY e.EmployeeID, e.FirstName,e.LastName, e.Title, c.CompanyName
ORDER BY TotalOrders DESC;
