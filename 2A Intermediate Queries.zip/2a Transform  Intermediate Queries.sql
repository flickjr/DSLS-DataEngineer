--1. Jumlah Customer yang melakukan order tiap bulan pada 1997
SELECT MONTH(OrderDate) as month, COUNT(CustomerID) as monthly_customers
FROM Orders
WHERE YEAR(OrderDate) = 1997
GROUP BY MONTH(OrderDate)
Order by Month;

-- 2. Employee dan Sales represntative
(Select *
from Employees
Where Title in ('Sales Representative')
);

--3. Top 5 Product quantity Januari (1997)
SELECT TOP 5 p.ProductName, SUM(od.Quantity) as TotalQuantity, o.OrderDate
FROM Products p
INNER JOIN [Order Details] od
ON p.ProductID = od.ProductID
INNER JOIN Orders o
ON od.OrderID = o.OrderID
WHERE MONTH(o.OrderDate) = 1
AND YEAR(o.OrderDate) = 1997
GROUP BY p.ProductName, o.OrderDate
ORDER BY TotalQuantity DESC;

--4 .Company yang melakukan Order Chai Juni 1997
SELECT  c.CompanyName ,o.OrderDate , p.ProductName
FROM Customers c
INNER JOIN Orders o
ON c.CustomerID = o.CustomerID
INNER JOIN [Order Details] od
ON o.OrderID = od.OrderID
INNER JOIN Products p
ON od.ProductID = p.ProductID
WHERE p.ProductName = 'Chai'
AND MONTH(o.OrderDate) = 6
AND YEAR(o.OrderDate) = 1997;

--5. Jumlah Order Id yang telah melakukan pembelian <=100, 100<x<=250, 250<x<=500, dan >500.
SELECT 
    SUM(CASE WHEN ("Order Details".UnitPrice*"Order Details".Quantity) <= 100 THEN 1 ELSE 0 END) as '<= 100', 
    SUM(CASE WHEN ("Order Details".UnitPrice*"Order Details".Quantity) > 100 AND ("Order Details".UnitPrice*"Order Details".Quantity) <= 250 THEN 1 ELSE 0 END) as '> 100 and <= 250', 
    SUM(CASE WHEN ("Order Details".UnitPrice*"Order Details".Quantity) > 250 AND ("Order Details".UnitPrice*"Order Details".Quantity) <= 500 THEN 1 ELSE 0 END) as '> 250 and <= 500', 
    SUM(CASE WHEN ("Order Details".UnitPrice*"Order Details".Quantity) > 500 THEN 1 ELSE 0 END) as '> 500' 
FROM "Order Details";

--6. Company name yang melakukan pembelian diatas 500 pada 1997.
SELECT CompanyName, ROUND(SUM([Order Details].UnitPrice*[Order Details].Quantity),2) as 'Total Sales'
FROM Customers
INNER JOIN Orders ON Customers.CustomerID = Orders.CustomerID 
INNER JOIN [Order Details] ON Orders.OrderID = [Order Details].OrderID 
WHERE YEAR(OrderDate) = 1997 
GROUP BY CompanyName 
HAVING SUM([Order Details].Quantity) > 500;

--7. Top 5 sales tertinggi tiap bulan di tahun 1997.
WITH CTE AS (
    SELECT MONTH(o.OrderDate) as Month, 
           p.ProductName, 
           SUM(od.UnitPrice * od.Quantity) AS Sales,
           ROW_NUMBER() OVER (PARTITION BY MONTH(o.OrderDate) ORDER BY SUM(od.UnitPrice * od.Quantity) DESC) as RowNumber
    FROM Orders o 
    JOIN [Order Details] od ON o.OrderID = od.OrderID
    JOIN Products p ON od.ProductID = p.ProductID
    WHERE YEAR(o.OrderDate) = 1997
    GROUP BY MONTH(o.OrderDate), p.ProductName
)
SELECT Month, ProductName, Sales
FROM CTE
WHERE RowNumber <= 5
ORDER BY Month, Sales DESC;

--8.View Order Details OrderID, ProductID, ProductName, UnitPrice, Quantity, Discount, Harga setelah diskon.
SELECT o.OrderID, od.ProductID, p.ProductName, od.UnitPrice, od.Quantity, od.Discount, 
       (od.UnitPrice * od.Quantity) * (1 - od.Discount) AS "Price After Discount"
FROM Orders o 
JOIN [Order Details] od ON o.OrderID = od.OrderID
JOIN Products p ON od.ProductID = p.ProductID

--9. Invoice CustomerID
DECLARE @customer_id AS NVARCHAR(5) = 'Insert Customer ID'

SELECT c.CustomerID, c.CompanyName as CustomerName, o.OrderID, o.OrderDate, o.RequiredDate, o.ShippedDate
FROM Customers c
JOIN Orders o ON c.CustomerID = o.CustomerID
WHERE c.CustomerID = @customer_id;